﻿namespace Server;
public class Banknote
{
    public string SMultR { get; set; }
    public string S { get; set; }
    public string R { get; set; }
    public string Sign { get; set; }
    public long Value { get; set; }
    public bool IsVerified { get; set; }
}
