﻿namespace SecretSharing.Polynoms
{
    public class CoefficientsSolver
    {
        static double LagrangeInterpolation(double[] x, double[] y, double xi)
        {
            double result = 0;
            for (int i = 0; i < x.Length; i++)
            {
                double term = y[i];
                for (int j = 0; j < x.Length; j++)
                {
                    if (i != j)
                    {
                        term *= (xi - x[j]) / (x[i] - x[j]);
                    }
                }
                result += term;
            }
            return result;
        }

        public static ushort[] GetCoefficients(uint[,,] points)
        {
            int polynomsCount = points.GetLength(0);
            int pointsCount = points.GetLength(1);
            var coefficients = new ushort[polynomsCount];

            var currentPoints = new uint[pointsCount, 2];

            var systemMatrix = new ulong[polynomsCount, polynomsCount + 1];
            var solved = new ulong[polynomsCount];

            for (int i = 0; i < polynomsCount; i++)
            {
                var x = new double[pointsCount];
                var y = new double[pointsCount];  

                for (int j = 0; j < pointsCount; j++)
                {
                    x[j] = points[i, j, 0];
                    y[j] = points[i, j, 1];
                }
                
                coefficients[i] = (ushort) LagrangeInterpolation(x, y, 0);
            }

            return coefficients;
        }
    }
}
